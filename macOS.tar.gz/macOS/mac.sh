#!/bin/bash

# Update and upgrade the system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y gnome-tweaks gnome-shell-extensions gnome-shell-extension-manager git

# Clone and install WhiteSur GTK theme
git clone https://github.com/vinceliuice/WhiteSur-gtk-theme.git
cd WhiteSur-gtk-theme
./install.sh -t all -N glassy
sudo ./tweaks.sh
cd ..

# Clone and install WhiteSur icon theme
git clone https://github.com/vinceliuice/WhiteSur-icon-theme.git
cd WhiteSur-icon-theme
./install.sh
cd ..

# Download and set macOS wallpaper (example link, replace with actual wallpaper link)
wget -O ~/Pictures/macOS_wallpaper.jpg https://4kwallpapers.com/abstract/mac...

# Set the wallpaper
gsettings set org.gnome.desktop.background picture-uri file:///home/$USER/Pictures/macOS_wallpaper.jpg

# Install macOS cursors
wget -O ~/Downloads/macOS-cursors.tar.gz https://www.gnome-look.org/p/1648124/
mkdir -p ~/.icons
tar -xzf ~/Downloads/macOS-cursors.tar.gz -C ~/.icons

# Install macOS fonts
git clone https://github.com/sahibjotsaggu/San-Francisco-Pro-Fonts.git
mkdir -p ~/.local/share/fonts
cp San-Francisco-Pro-Fonts/*.ttf ~/.local/share/fonts/
fc-cache -f -v

# Install GNOME extensions for blur and magic lamp effect
gnome-extensions install https://extensions.gnome.org/extension/3193/blur-my-shell/
gnome-extensions install https://extensions.gnome.org/extension/3270/compiz-alike-magic-lamp-effect/

# Enable the installed extensions
gnome-extensions enable blur-my-shell@aunetx
gnome-extensions enable compiz-alike-magic-lamp-effect@hermes83

echo "Setup and customization complete. Please log out and log back in for all changes to take effect."

